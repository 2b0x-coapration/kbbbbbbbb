'use strict';
// supergo:// internal pages (same look as the Linux version)
const fs = require('fs'), path = require('path');
const A = JSON.parse(fs.readFileSync(path.join(__dirname, 'pages', 'assets.json'), 'utf8'));
const WELCOME = fs.readFileSync(path.join(__dirname, 'pages', 'welcome.html'), 'utf8');

const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const host = u => { try { return new URL(u).hostname; } catch (e) { return ''; } };
const hue = h => { let x = 0; for (const c of h) x = (x * 31 + c.charCodeAt(0)) % 360; return x; };
const ENGINES = { 'Google': 'https://www.google.com/search?q=%s', 'Bing': 'https://www.bing.com/search?q=%s', 'DuckDuckGo': 'https://duckduckgo.com/?q=%s', 'searchgo!': 'https://searchgo.base44.app/?q=%s' };

const HOME_CSS = 'body{background:#000;color:#fff;font-family:"Segoe UI",sans-serif;margin:0;padding:18vh 20px 160px;text-align:center}' +
  'h1{font-size:15px;letter-spacing:6px;font-weight:600;color:#8e8e93;margin:0 0 26px}form{max-width:640px;margin:0 auto}' +
  'input{width:100%;box-sizing:border-box;padding:15px 20px;font-size:17px;border-radius:26px;border:0;outline:0;background:#1c1c1e;color:#fff;font-family:inherit}input::placeholder{color:#8e8e93}' +
  'p{display:flex;flex-wrap:wrap;justify-content:center;gap:18px;margin:34px auto 0;max-width:760px}a{width:72px;text-decoration:none;color:#fff;font-size:12px}' +
  'i{display:block;width:60px;height:60px;line-height:60px;margin:0 auto 6px;border-radius:16px;background:#1c1c1e;font-style:normal;font-size:24px;color:#0a84ff}a:hover i{background:#2c2c2e}';
function css(ctx) {
  const dark = ctx.private ? true : ctx.dark();
  return ':root{' + (dark ? A.DARK_VARS : A.LIGHT_VARS) + '}' + A.PAGE_CSS + (ctx.S.anim ? '' : '*,*::before,*::after{animation:none!important;transition:none!important}') + (ctx.private ? A.PRIV_CSS : '');
}
function page(ctx, title, body, active) {
  const nav = [['newtab', 'Home'], ['weather', 'Weather'], ['bookmarks', 'Bookmarks'], ['history', 'History'], ['downloads', 'Downloads'], ['vpn', 'VPN'], ['settings', 'Settings'], ['about', 'About']]
    .map(([k, n]) => '<a href="supergo://' + k + '"' + (k === active ? ' class=on' : '') + '>' + n + '</a>').join('');
  return '<!doctype html><meta charset=utf-8><meta name=viewport content="width=device-width,initial-scale=1"><title>' + esc(title) + '</title><style>' + css(ctx) +
    '</style><div class=top><a class=logo href="supergo://newtab">SUPERGO</a><div class=nav>' + nav + '</div></div>' + body;
}
function card(u, t) {
  const h = host(u).replace(/^www\./, '');
  return '<a class=card href="' + esc(u) + '"><div class=cov style="--h:' + hue(h) + '"><span class=ini>' + esc((h[0] || '?').toUpperCase()) + '</span></div><div class=cap>' + esc((t || h).slice(0, 46)) + '</div></a>';
}
const SPACE_CSS = '#sp{position:fixed;inset:0;z-index:-1;width:100%;height:100%;background:radial-gradient(ellipse at 70% 20%,#1b1040 0,#07060d 55%,#000 100%)}#wxm{position:fixed;top:18px;right:20px;padding:12px 18px;border-radius:18px;background:rgba(255,255,255,.08);backdrop-filter:blur(18px);-webkit-backdrop-filter:blur(18px);border:1px solid rgba(255,255,255,.14);text-align:left;cursor:pointer;min-width:120px}#wxm .m{font-size:12px;color:#c7c7cc;margin-top:4px}body{background:transparent!important}';
const SPACE_JS = `(function(){var c=document.getElementById('sp'),x=c.getContext('2d'),W,H,S=[],N=[];function R(){W=c.width=innerWidth;H=c.height=innerHeight;S=[];for(var i=0;i<Math.min(320,W*H/5000);i++)S.push({x:Math.random()*W,y:Math.random()*H,z:Math.random()*2+.3,t:Math.random()*6})}R();addEventListener('resize',R);setInterval(function(){if(N.length<2)N.push({x:Math.random()*W,y:Math.random()*H*.5,l:0})},3500);function F(){x.clearRect(0,0,W,H);var r=Math.min(W,H)*.22,g=x.createRadialGradient(W*.8,H*.85,0,W*.8,H*.85,r);g.addColorStop(0,'#5a7bd8');g.addColorStop(.7,'#1c2a66');g.addColorStop(1,'rgba(0,0,0,0)');x.fillStyle=g;x.beginPath();x.arc(W*.8,H*.85,r,0,7);x.fill();S.forEach(function(s){s.t+=.03;s.x-=s.z*.12;if(s.x<0)s.x=W;x.globalAlpha=.5+.5*Math.sin(s.t);x.fillStyle='#fff';x.fillRect(s.x,s.y,s.z,s.z)});x.globalAlpha=1;N=N.filter(function(n){n.l++;n.x+=9;n.y+=4;x.strokeStyle='rgba(255,255,255,'+(1-n.l/40)+')';x.beginPath();x.moveTo(n.x,n.y);x.lineTo(n.x-60,n.y-27);x.stroke();return n.l<40});requestAnimationFrame(F)}F()})();`;
const WX_JS = `
(function(){
function $(i){return document.getElementById(i)}
var ICON={0:'\u2600\uFE0F',1:'\uD83C\uDF24\uFE0F',2:'\u26C5',3:'\u2601\uFE0F',45:'\uD83C\uDF2B\uFE0F',48:'\uD83C\uDF2B\uFE0F',51:'\uD83C\uDF26\uFE0F',53:'\uD83C\uDF26\uFE0F',55:'\uD83C\uDF26\uFE0F',61:'\uD83C\uDF27\uFE0F',63:'\uD83C\uDF27\uFE0F',65:'\uD83C\uDF27\uFE0F',71:'\uD83C\uDF28\uFE0F',73:'\uD83C\uDF28\uFE0F',75:'\uD83C\uDF28\uFE0F',80:'\uD83C\uDF26\uFE0F',81:'\uD83C\uDF27\uFE0F',82:'\u26C8\uFE0F',95:'\u26C8\uFE0F',96:'\u26C8\uFE0F',99:'\u26C8\uFE0F'};
var TXT={0:'Clear sky',1:'Mainly clear',2:'Partly cloudy',3:'Overcast',45:'Fog',48:'Rime fog',51:'Light drizzle',53:'Drizzle',55:'Heavy drizzle',61:'Light rain',63:'Rain',65:'Heavy rain',71:'Light snow',73:'Snow',75:'Heavy snow',80:'Rain showers',81:'Rain showers',82:'Violent showers',95:'Thunderstorm',96:'Thunderstorm',99:'Thunderstorm'};
function esc(s){return String(s).replace(/[&<>"]/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]})}
function api(p){return fetch('supergo://api/'+p).then(function(r){return r.json()})}
window.sgWx=function(mini){api('wx').then(function(r){if(r.error)throw 0;var w=r.data,c=w.current,l=r.loc,F=r.units==='F';
 function T(x){x=Math.round(x);return F?Math.round(x*9/5+32)+'\u00B0F':x+'\u00B0C'}
 if(mini){$('wxm').innerHTML='<div style="font-size:30px;line-height:1">'+(ICON[c.weather_code]||'')+' '+T(c.temperature_2m)+'</div><div class=m>'+(TXT[c.weather_code]||'')+' \u00B7 '+esc(l.n)+'</div>';$('wxm').onclick=function(){location.href='supergo://weather'};return}
 var h='<div class=note><div style="font-size:44px">'+(ICON[c.weather_code]||'')+' '+T(c.temperature_2m)+'</div><div>'+(TXT[c.weather_code]||'')+'</div><div class=m>'+esc(l.n)+' \u00B7 wind '+Math.round(c.wind_speed_10m)+' km/h \u00B7 humidity '+c.relative_humidity_2m+'%</div></div><div class=g2>';
 w.daily.time.forEach(function(d,i){h+='<div class=card><div style="font-size:26px">'+(ICON[w.daily.weather_code[i]]||'')+'</div><div class=cap>'+new Date(d+'T12:00').toLocaleDateString(undefined,{weekday:'short'})+'</div><div class=m>'+T(w.daily.temperature_2m_max[i])+' / '+T(w.daily.temperature_2m_min[i])+'</div></div>'});
 $('wx').innerHTML=h+'</div>'}).catch(function(){var e=mini?$('wxm'):$('wx');if(e)e.innerHTML='<span class=m>Weather unavailable (offline?)</span>'})};
window.sgUnits=function(){api('units').then(function(){sgWx(false)})};
window.sgFind=function(e){e.preventDefault();var q=$('wq').value.trim();if(!q)return;api('find?q='+encodeURIComponent(q)).then(function(j){var r=j.results||[];
 $('wres').innerHTML=r.length?r.map(function(x,i){return '<a class=c href="#" data-i="'+i+'">'+esc(x.n)+'</a>'}).join(''):'<span class=m>No city found.</span>';
 [].forEach.call($('wres').querySelectorAll('a'),function(a){a.onclick=function(ev){ev.preventDefault();var x=r[+a.getAttribute('data-i')];api('set?n='+encodeURIComponent(x.n)+'&la='+x.la+'&lo='+x.lo).then(function(){location.reload()})}})})};
})();`;

function render(name, q, ctx) {
  const S = ctx.S; let note = '';
  const T = ctx.token, ok = q.t === T;
  const links = (base, extra) => [['hour', 'last hour'], ['day', 'last 24 hours'], ['week', 'last 7 days'], ['all', 'all time']].map(([k, n]) => '<a href="supergo://' + base + '?clear=' + k + '&t=' + T + (extra || '') + '">' + n + '</a>').join(' · ');
  switch (name) {
    case 'newtab': {
      const tmpl = JSON.stringify(ctx.engineUrl()).replace(/</g, '\\u003c');
      const js = 'var T=' + tmpl + ';' + A.SEARCH_JS.replace(/^var T=__T__;/, '');
      const tiles = ctx.bms().slice().sort((a, b) => (b.ts - a.ts) || (b.id - a.id)).map(b => {
        const t = (b.title || '').trim(), L = (t[0] || '?').toUpperCase();
        return '<a href="' + esc(b.url) + '"><i>' + esc(L) + '</i><span>' + esc(t.length > 12 ? t.slice(0, 12) : t) + '</span></a>';
      }).join('');
      const eng = S.engine === 'Custom' ? 'the web' : S.engine;
      return '<!doctype html><meta charset=utf-8><meta name=viewport content="width=device-width,initial-scale=1"><title>New tab</title><style>' + HOME_CSS + '</style><style>' + SPACE_CSS + '</style><canvas id=sp></canvas>' + (S.weather_on ? '<div id=wxm><span class=m>Loading weather\u2026</span></div>' : '') + '<h1>SUPERGO</h1>' +
        '<form onsubmit="go(event)"><input id=q placeholder="Search ' + esc(eng) + ' or enter website" autocomplete=off autofocus></form>' + (tiles ? '<p>' + tiles + '</p>' : '') + '<script>' + js + '</script><script>' + SPACE_JS + '</script>' + (S.weather_on ? '<script>' + WX_JS + ';sgWx(true)</script>' : '');
    }
    case 'weather':
      return page(ctx, 'Weather', '<h1>Weather</h1><form onsubmit="sgFind(event)"><input name=s id=wq placeholder="Search for a city"> <a class=m href="#" onclick="sgUnits();return false">°C / °F</a></form><div id=wres></div><div id=wx><span class=m>Loading…</span></div><p class=m>Forecast data by Open-Meteo.com (CC BY 4.0).</p><script>' + WX_JS + ';sgWx(false)</script>', 'weather');
    case 'welcome':
      if (q.done) { ctx.act('welcomeDone', q); return '<!doctype html><meta charset=utf-8><title>SUPERGO</title><body style="background:#07060d"><script>location.replace(' + JSON.stringify(ctx.home()).replace(/</g, '\\u003c') + ')</script>'; }
      return WELCOME.replace('__ANIM__', S.anim ? 'true' : 'false');
    case 'history': {
      if (ok) { if (q.del) ctx.act('histDel', q); if (q.clear) ctx.act('histClear', q); }
      const s = (q.s || '').toLowerCase();
      const rows = ctx.hist().filter(r => !s || r.url.toLowerCase().includes(s) || (r.title || '').toLowerCase().includes(s)).sort((a, b) => b.ts - a.ts).slice(0, 500);
      let b = '<h1>History</h1><form><input name=s value="' + esc(q.s || '') + '" placeholder="Search history"></form><p class=m>Clear: ' + links('history') + '</p>';
      rows.forEach(r => { b += '<div class=c><a href="' + esc(r.url) + '">' + esc(r.title || r.url) + '</a> <span class=m>' + esc(host(r.url)) + ' · ' + new Date(r.ts * 1000).toLocaleString() + '</span> <a class=m style="float:right" href="supergo://history?del=' + r.id + '&t=' + T + '&s=' + encodeURIComponent(q.s || '') + '">delete</a></div>'; });
      return page(ctx, 'History', rows.length ? b : b + '<p class=m>No history.</p>', 'history');
    }
    case 'bookmarks': {
      if (ok && q.del) ctx.act('bmDel', q);
      const rows = ctx.bms().slice().sort((a, b) => (a.folder + a.title).localeCompare(b.folder + b.title));
      let b = '<h1>Bookmarks</h1>', cur = null;
      rows.forEach(r => { if (r.folder !== cur) { b += '<h3>' + esc(r.folder) + '</h3>'; cur = r.folder; } b += '<div class=c><a href="' + esc(r.url) + '">' + esc(r.title || r.url) + '</a> <span class=m>' + esc(host(r.url)) + '</span><a class=m style="float:right" href="supergo://bookmarks?del=' + r.id + '&t=' + T + '">remove</a></div>'; });
      return page(ctx, 'Bookmarks', rows.length ? b : b + '<p class=m>No bookmarks yet. Press Ctrl+D on a page.</p>', 'bookmarks');
    }
    case 'downloads': {
      if (ok && q.open) ctx.act('dlOpen', q); if (ok && q.show) ctx.act('dlShow', q); if (ok && q.clear) ctx.act('dlClear', q);
      const rows = ctx.downloads();
      let b = '<h1>Downloads</h1><p class=m><a href="supergo://downloads?clear=1&t=' + T + '">Clear list</a></p>';
      rows.forEach(d => { b += '<div class=c><b>' + esc(d.name) + '</b> <span class=m>' + esc(d.status) + '</span>' + (d.state === 'done' ? ' <a class=m style="float:right" href="supergo://downloads?show=' + d.id + '&t=' + T + '">show in folder</a><a class=m style="float:right;margin-right:14px" href="supergo://downloads?open=' + d.id + '&t=' + T + '">open</a>' : '') + '</div>'; });
      return page(ctx, 'Downloads', (rows.length ? b : b + '<p class=m>No downloads yet.</p>') + '<meta http-equiv=refresh content="3">', 'downloads');
    }
    case 'settings': {
      if (ok) note = ctx.act('settings', q) || '';
      const chk = k => S[k] ? ' checked' : '';
      const opts = Object.keys(ENGINES).concat(['Custom']).map(n => '<option' + (n === S.engine ? ' selected' : '') + '>' + n + '</option>').join('');
      const topts = [['auto', 'Auto (follow system)'], ['dark', 'Dark'], ['light', 'Light']].map(([k, n]) => '<option value=' + k + (S.theme === k ? ' selected' : '') + '>' + n + '</option>').join('');
      const chips = Object.keys(ENGINES).map(n => '<a class="btn' + (S.engine === n ? ' on' : '') + '" href="supergo://settings?quick=' + encodeURIComponent(n) + '&t=' + T + '">' + esc(n) + (S.engine === n ? ' &#10003;' : '') + '</a>').join('');
      const b = '<h1>Settings</h1>' + (note ? '<div class=note>' + esc(note) + '</div>' : '') +
        '<style>.st{max-width:680px}.st .r{display:flex;align-items:center;justify-content:space-between;gap:16px;padding:12px 0;border-bottom:1px solid var(--line)}.st input[type=text],.st select{background:var(--inp);color:var(--fg);border:1px solid var(--line);border-radius:12px;padding:8px 12px;font:inherit;min-width:300px}.st input[type=checkbox]{width:20px;height:20px}.st button{background:var(--card);color:var(--fg);border:1px solid var(--line);border-radius:999px;padding:9px 22px;font:inherit;cursor:pointer;margin-top:18px}.st button:hover{background:var(--card2)}.btn{display:inline-block;margin:4px 10px 4px 0;padding:9px 20px;border-radius:10px;border:1px solid var(--line);background:var(--card);color:var(--fg);font-size:14px}.btn:hover{background:var(--card2)}.btn.on{border-color:var(--accent)}.btn.pri{background:var(--accent);border-color:transparent;color:#fff}</style>' +
        '<form class=st action="supergo://settings"><input type=hidden name=t value="' + T + '"><input type=hidden name=save value=1>' +
        '<div class=r><span>Search engine</span><select name=engine>' + opts + '</select></div>' +
        '<div class=r><span>Custom engine URL <span class=m>(use %s for the query)</span></span><input type=text name=custom value="' + esc(S.custom_engine) + '"></div>' +
        '<div class=r><span>Homepage</span><input type=text name=home value="' + esc(S.homepage) + '"></div>' +
        '<div class=r><span>Restore tabs on start</span><input type=checkbox name=restore value=1' + chk('restore') + '></div>' +
        '<div class=r><span>uBlock ad blocker</span><input type=checkbox name=adblock value=1' + chk('adblock') + '></div>' +
        '<div class=r><span>Animations</span><input type=checkbox name=anim value=1' + chk('anim') + '></div>' +
        '<div class=r><span>Appearance</span><select name=theme>' + topts + '</select></div>' +
        '<div class=r><span>Show weather on the new tab page</span><input type=checkbox name=wx value=1' + chk('weather_on') + '></div>' +
        '<div class=r><span>Download folder</span><input type=text name=ddir value="' + esc(S.download_dir || ctx.defaultDl()) + '"></div>' +
        '<div class=r><span>Ask where to save</span><input type=checkbox name=ask value=1' + chk('ask_save') + '></div>' +
        '<button type=submit>Save settings</button></form>' +
        '<h3>Quick search engine</h3><p class=m>Tap one to switch right away.</p><p>' + chips + '</p>' +
        '<h3>Welcome tour</h3><p class=m>Replay the 8-step introduction to how SUPERGO works.</p><p><a class="btn pri" href="supergo://welcome">&#9654;&nbsp; Start welcome tour</a></p>' +
        '<h3>Privacy</h3><p class=m>Clear history &amp; site data: ' + links('settings') + ' &nbsp;|&nbsp; <a href="supergo://settings?resetperms=1&t=' + T + '">Reset site permissions</a></p>';
      return page(ctx, 'Settings', b, 'settings');
    }
    case 'vpn': {
      if (ok) note = ctx.act('vpn', q) || '';
      const v = ctx.vpn();
      const rows = v.mine.map(n => '<div class=c>' + (v.sel === n.id ? '<b>● </b>' : '') + '<a href="supergo://vpn?use=' + n.id + '&t=' + T + '">' + esc(n.name) + '</a> <span class=m>' + esc(n.proto) + ' · ' + esc(n.host) + ':' + n.port + '</span> <a class=m style="float:right" href="supergo://vpn?rm=' + n.id + '&t=' + T + '">remove</a></div>').join('');
      const b = '<h1>VPN</h1>' + (note ? '<div class=note>' + esc(note) + '</div>' : '') +
        '<div class=note><b>Status:</b> ' + esc(v.text) + '<br>' + (v.state === 'off' ? '<a href="supergo://vpn?connect=1&t=' + T + '">Connect</a>' : '<a href="supergo://vpn?disconnect=1&t=' + T + '">Disconnect</a>') +
        '<br><span class=m>Core: ' + esc(v.core || 'not found - put xray.exe in ' + v.coreDir) + '</span></div>' +
        '<h3>Server</h3><div class=c>' + (v.sel === 'auto' ? '<b>● </b>' : '') + '<a href="supergo://vpn?use=auto&t=' + T + '">Automatic</a> <span class=m>tests the bundled public servers and picks a working one</span></div>' + rows +
        '<h3>Add your own</h3><form action="supergo://vpn" method=get><input type=hidden name=t value="' + T + '"><textarea name=add rows=4 style="width:min(680px,92vw);background:var(--inp);color:var(--fg);border:1px solid var(--line);border-radius:12px;padding:10px;font:13px monospace" placeholder="Paste vless:// vmess:// trojan:// ss:// links, a subscription link text, or a JSON config"></textarea><p><button style="background:var(--card);color:var(--fg);border:1px solid var(--line);border-radius:999px;padding:9px 22px;font:inherit;cursor:pointer">Add</button></p></form>' +
        '<p class=m>Only the SUPERGO browser goes through the VPN - the rest of your PC is untouched. Bundled servers are public third-party servers: use your own for anything sensitive.</p>';
      return page(ctx, 'VPN', b, 'vpn');
    }
    case 'about': {
      const m = ctx.meta;
      return page(ctx, 'About SUPERGO', '<h1>SUPERGO ' + esc(ctx.version) + '</h1><div class=note>Windows edition<br>Chromium ' + esc(process.versions.chrome) + ' · Electron ' + esc(process.versions.electron) + ' · Node ' + esc(process.versions.node) + '</div>' +
        '<div class=note><b>uBlock (built in)</b> - ' + (m.rules || 0) + ' source rules, built ' + esc(m.built || '-') + ', from: ' + esc((m.lists || []).join(', ')) + '.<br><span class=m>Filter lists are converted from uBlock Origin / EasyList sources (GPLv3, CC BY-SA 3.0, CC0). Host and third-party rules plus cosmetic filters are applied.</span></div>' +
        '<div class=note><b>VPN (built in)</b> - runs the xray / v2ray core as your own user (no admin). Add your own vless / vmess / trojan / ss link or JSON config, or use Automatic.</div>' +
        '<div class=note>Weather: forecast data by Open-Meteo.com (CC BY 4.0). Your approximate location comes from an IP lookup unless you choose a city yourself; turn weather off in Settings.</div>' +
        '<div class=note>License: MIT. Components: Electron / Chromium (BSD, LGPL, etc.).</div>', 'about');
    }
  }
  return page(ctx, 'Not found', '<h1>Unknown SUPERGO page: ' + esc(name) + '</h1>');
}
module.exports = { render, ENGINES, esc };
