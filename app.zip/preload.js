'use strict';
const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('sg', {
  send: (cmd, arg) => ipcRenderer.send('sg', cmd, arg),
  onState: cb => ipcRenderer.on('state', (e, s) => cb(s)),
  onCmd: cb => ipcRenderer.on('cmd', (e, c, a) => cb(c, a)),
  onList: cb => ipcRenderer.on('list', (e, p) => cb(p)),
});
