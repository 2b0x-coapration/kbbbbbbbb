'use strict';
const { app, BrowserWindow, BrowserView, Menu, MenuItem, protocol, session, ipcMain, shell, dialog, nativeTheme, clipboard } = require('electron');
const fs = require('fs'), path = require('path'), zlib = require('zlib'), crypto = require('crypto');
const pages = require('./pages');
const { net } = require('electron');
const v2 = require('./v2core');

const VERSION = '1.9.0';
app.setName('SUPERGO');
protocol.registerSchemesAsPrivileged([{ scheme: 'supergo', privileges: { standard: true, secure: true, supportFetchAPI: true, corsEnabled: true } }]);
if (!app.requestSingleInstanceLock()) { app.quit(); process.exit(0); }
app.commandLine.appendSwitch('enable-features', 'OverlayScrollbar');

const UD = app.getPath('userData');
const TOKEN = crypto.randomBytes(8).toString('hex');
const BAR_W = 420, BAR_H = 122;   // bar view = 400x102 bar + 10px margins
const ICON = path.join(__dirname, 'icon.png');
const ICO = path.join(__dirname, 'icon.ico');

// ------------------------------------------------------------------ settings & data
const DEFAULTS = { engine: 'Google', custom_engine: 'https://www.google.com/search?q=%s', homepage: 'supergo://newtab', restore: true, theme: 'auto', download_dir: '', ask_save: false,
  perms: {}, adblock: true, adblock_off: [], vpn: { sel: 'auto', mine: [] }, anim: true, side: true, welcome_done: false, weather_on: true };
let S = JSON.parse(JSON.stringify(DEFAULTS));
const jpath = n => path.join(UD, n);
function readJson(n, d) { try { return JSON.parse(fs.readFileSync(jpath(n), 'utf8')); } catch (e) { return d; } }
function writeJson(n, o) { try { fs.mkdirSync(UD, { recursive: true }); const t = jpath(n) + '.tmp'; fs.writeFileSync(t, JSON.stringify(o)); fs.renameSync(t, jpath(n)); } catch (e) {} }
function loadSettings() {
  Object.assign(S, readJson('settings.json', {}));
  for (const k of ['engine', 'custom_engine', 'homepage', 'download_dir']) if (typeof S[k] !== 'string') S[k] = DEFAULTS[k];
  for (const k of ['restore', 'ask_save', 'adblock', 'anim', 'side', 'welcome_done', 'weather_on']) S[k] = !!S[k];
  if (!['auto', 'dark', 'light'].includes(S.theme)) S.theme = 'auto';
  if (!S.perms || typeof S.perms !== 'object') S.perms = {};
  if (!Array.isArray(S.adblock_off)) S.adblock_off = [];
  if (!S.vpn || typeof S.vpn !== 'object') S.vpn = {};
  S.welcome_done = true; S.vpn.sel = S.vpn.sel || 'auto'; if (!S.weather || typeof S.weather !== 'object') S.weather = { loc: null, units: 'C' }; if (!Array.isArray(S.vpn.mine)) S.vpn.mine = [];
}
const saveSettings = () => writeJson('settings.json', S);
let HIST = [], BMS = [], nextId = 1;
function loadData() {
  HIST = readJson('history.json', []); BMS = readJson('bookmarks.json', []);
  nextId = 1 + Math.max(0, ...HIST.map(h => h.id || 0), ...BMS.map(b => b.id || 0));
}
let hT = null;
const saveHist = () => { clearTimeout(hT); hT = setTimeout(() => writeJson('history.json', HIST.slice(-5000)), 1500); };
const saveBms = () => writeJson('bookmarks.json', BMS);

const ENGINES = pages.ENGINES;
const engineUrl = () => S.engine === 'Custom' ? S.custom_engine : (ENGINES[S.engine] || ENGINES.Google);
function toUrl(text) {
  const t = text.trim();
  if (/^[a-zA-Z][a-zA-Z0-9+.-]*:\/\//.test(t) || /^(about:|data:)/.test(t)) return t;
  if (!/\s/.test(t) && (t.includes('.') || t.startsWith('localhost'))) return (/^(localhost|127\.)/.test(t) ? 'http://' : 'https://') + t;
  return engineUrl().replace('%s', encodeURIComponent(t));
}
const isDark = () => true;
function applyTheme() { nativeTheme.themeSource = 'dark'; }
const defaultDl = () => app.getPath('downloads');
const homeUrl = () => /^(https?|supergo):\/\//.test(S.homepage) ? S.homepage : 'supergo://newtab';

// ------------------------------------------------------------------ windows / tabs
const wins = new Map();          // shell webContents id -> Win
const sessions = new Map();      // partition -> session
let lastWin = null, privCounter = 0, closedTabs = [];

function sessionFor(partition, priv) {
  let ses = sessions.get(partition);
  if (ses) return ses;
  ses = session.fromPartition(partition); sessions.set(partition, ses);
  ses.protocol.registerBufferProtocol('supergo', (req, cb) => serveInternal(req, cb, priv));
  ses.setPermissionRequestHandler((wc, perm, cb, details) => askPermission(wc, perm, cb, details, priv));
  ses.setPermissionCheckHandler((wc, perm, origin) => {
    if (['clipboard-sanitized-write', 'fullscreen', 'pointerLock'].includes(perm)) return true;
    return S.perms[hostOf(origin) + '|' + perm] === true;
  });
  ses.on('will-download', (e, item, wc) => onDownload(ses, e, item, wc));
  attachAdblock(ses); applyProxy(ses);
  return ses;
}
function hostOf(u) { try { return new URL(u).hostname; } catch (e) { return ''; } }

const uiWins = new Map();     // overlay (bar) webContents id -> Win
function shownUrl(u) { if (/^supergo:\/\/error/.test(u)) { try { return new URL(u).searchParams.get('u') || ''; } catch (e) {} } return u; }
const bmSorted = () => BMS.slice().sort((a, b) => (b.ts - a.ts) || (b.id - a.id));

class Win {
  constructor(priv, urls) {
    this.private = !!priv;
    this.partition = priv ? 'private-' + (++privCounter) : 'persist:supergo';
    this.ses = sessionFor(this.partition, this.private);
    this.tabs = []; this.active = null; this.fs = false; this.t = null; this.mode = 'bar'; this.privPart = null; this.toastT = null; this.progT = null; this.progOn = false; this.toastOn = false;
    const bw = this.bw = new BrowserWindow({ width: 1280, height: 800, minWidth: 560, minHeight: 360, show: false, title: 'SuperGo', icon: fs.existsSync(ICO) ? ICO : ICON, backgroundColor: '#000000',
      webPreferences: { sandbox: true, contextIsolation: true, nodeIntegration: false } });
    this.id = bw.webContents.id; wins.set(this.id, this); lastWin = this;
    bw.removeMenu && bw.removeMenu();
    bw.loadURL('data:text/html,<body style="background:%23000">').catch(() => {});
    // the bar is a transparent view floating over the page in the bottom-left corner (like the .deb)
    const ui = this.ui = new BrowserView({ webPreferences: { preload: path.join(__dirname, 'preload.js'), sandbox: true, contextIsolation: true, nodeIntegration: false } });
    const uiId = ui.webContents.id;
    ui.setBackgroundColor('#00000000'); uiWins.set(uiId, this);
    ui.webContents.loadFile(path.join(__dirname, 'shell', 'shell.html'));
    ui.webContents.on('before-input-event', (e, inp) => { if (this.key(inp)) e.preventDefault(); });
    ui.webContents.on('will-navigate', e => e.preventDefault());
    ui.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
    bw.addBrowserView(ui);
    this.prog = this.overlay('<body style="margin:0;overflow:hidden;background:transparent"><div id=b style="height:2px;width:0;background:#0a84ff"></div>');
    this.toastV = this.overlay('<body style="margin:0;overflow:hidden;background:transparent"><div id=t style="height:100vh;display:flex;align-items:center;justify-content:center;background:#2c2c2e;color:#fff;border-radius:16px;font:14px \'Segoe UI\',system-ui,sans-serif;white-space:nowrap;overflow:hidden"></div>');
    bw.webContents.on('before-input-event', (e, inp) => { if (this.key(inp)) e.preventDefault(); });
    bw.webContents.on('will-navigate', e => e.preventDefault());
    bw.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
    bw.on('page-title-updated', e => e.preventDefault());
    let shown = false; const show = () => { if (!shown && !bw.isDestroyed()) { shown = true; bw.show(); } };
    bw.once('ready-to-show', show); setTimeout(show, 1500);
    bw.on('resize', () => this.layout()); bw.on('maximize', () => this.layout()); bw.on('unmaximize', () => this.layout());
    bw.on('focus', () => { lastWin = this; });
    bw.on('close', () => { if (!this.private) saveSession(this); });
    bw.on('closed', () => {
      wins.delete(this.id); uiWins.delete(uiId); this.tabs.forEach(t => destroyTab(t));
      [ui, this.prog, this.toastV].forEach(v => destroyTab({ wc: v.webContents }));
      if (lastWin === this) lastWin = [...wins.values()][0] || null;
      if (this.private) sessions.delete(this.partition); if (this.privPart) sessions.delete(this.privPart);
    });
    (urls && urls.length ? urls : [homeUrl()]).forEach((u, i) => this.newTab(u, { switch: i === 0 || true }));
    this.push();
  }
  get cur() { return this.active; }
  overlay(html) {
    const v = new BrowserView({ webPreferences: { sandbox: true, contextIsolation: true, nodeIntegration: false } });
    v.setBackgroundColor('#00000000'); v.webContents.loadURL('data:text/html;charset=utf-8,' + encodeURIComponent(html)).catch(() => {});
    return v;
  }
  showV(v) { try { if (!this.bw.getBrowserViews().includes(v)) this.bw.addBrowserView(v); } catch (e) {} }
  hideV(v) { try { this.bw.removeBrowserView(v); } catch (e) {} }
  size() { const [w, h] = this.bw.getContentSize(); return { w, h }; }
  // the page fills the whole window; the bar floats over it
  layout() {
    if (this.bw.isDestroyed()) return;
    const { w, h } = this.size();
    if (this.active) this.active.view.setBounds({ x: 0, y: 0, width: w, height: h });
    this.layoutUi();
  }
  layoutUi() {
    if (this.bw.isDestroyed()) return;
    const { w, h } = this.size();
    this.ui.setBounds(this.mode === 'full' ? { x: 0, y: 0, width: w, height: h } : { x: 0, y: Math.max(0, h - BAR_H), width: Math.min(BAR_W, w), height: BAR_H });
  }
  raise() {
    try {
      if (this.progOn) this.bw.setTopBrowserView(this.prog);
      if (!this.fs) this.bw.setTopBrowserView(this.ui);
      if (this.toastOn) this.bw.setTopBrowserView(this.toastV);
    } catch (e) {}
  }
  progress(on) {
    clearTimeout(this.progT);
    const js = s => this.prog.webContents.executeJavaScript(s).catch(() => {});
    if (on) {
      this.showV(this.prog); this.prog.setBounds({ x: 0, y: 0, width: this.size().w, height: 2 }); this.progOn = true; this.raise();
      js("var b=document.getElementById('b');b.style.transition='none';b.style.width='0';void b.offsetWidth;b.style.transition='width 6s cubic-bezier(.1,.7,.2,1)';b.style.width='80%'");
    } else if (this.progOn) {
      js("var b=document.getElementById('b');b.style.transition='width .2s';b.style.width='100%'");
      this.progT = setTimeout(() => { this.progOn = false; this.hideV(this.prog); }, 260);
    }
  }
  toast(text, ms) {
    const { w, h } = this.size(), tw = Math.min(w - 40, Math.max(120, Math.round(text.length * 8.4) + 40));
    this.toastV.setBounds({ x: Math.round((w - tw) / 2), y: Math.max(0, h - 22 - 38), width: tw, height: 38 });
    this.toastV.webContents.executeJavaScript('document.getElementById("t").textContent=' + JSON.stringify(text)).catch(() => {});
    this.showV(this.toastV); this.toastOn = true; this.raise();
    clearTimeout(this.toastT); this.toastT = setTimeout(() => { this.toastOn = false; this.hideV(this.toastV); }, ms || 2200);
  }
  setTitle() { const t = this.active; this.bw.setTitle(t && t.title && t.title !== 'New tab' ? t.title + ' \u2014 SuperGo' : 'SuperGo'); }
  newTab(url, o) {
    o = o || {};
    const priv = !!(o.priv || this.private);
    const partition = priv ? (this.private ? this.partition : (this.privPart || (this.privPart = 'private-' + (++privCounter)))) : this.partition;
    sessionFor(partition, priv);
    const view = new BrowserView({ webPreferences: { partition, sandbox: true, contextIsolation: true, nodeIntegration: false, spellcheck: true } });
    view.setBackgroundColor('#000000');
    const t = { id: ++tabSeq, view, wc: view.webContents, title: '', url: '', fav: '', loading: false, win: this, priv };
    this.tabs.splice(o.pos == null ? this.tabs.length : o.pos, 0, t);
    this.hook(t);
    t.wc.setWebRTCIPHandlingPolicy(vpn.state === 'off' ? 'default_public_interface_only' : 'disable_non_proxied_udp');
    if (o.switch !== false) this.switchTo(t);
    t.wc.loadURL(url || 'supergo://newtab').catch(() => {});
    this.push();
    return t;
  }
  hook(t) {
    const wc = t.wc, p = () => this.push();
    wc.on('page-title-updated', (e, title) => { t.title = title; recordTitle(this, t); if (this.active === t) this.setTitle(); p(); });
    wc.on('did-start-loading', () => { t.loading = true; if (this.active === t) this.progress(true); p(); });
    wc.on('did-stop-loading', () => { t.loading = false; if (this.active === t) this.progress(false); p(); });
    wc.on('did-start-navigation', (e, url, inPlace, main) => { if (main && !inPlace) blockedCount.set(wc.id, 0); });
    const nav = (e, url) => { t.url = url; if (!/^(supergo|data|about):/.test(url)) recordVisit(this, t, url); p(); };
    wc.on('did-navigate', nav); wc.on('did-navigate-in-page', (e, url, main) => { if (main) nav(e, url); });
    wc.on('page-favicon-updated', (e, f) => { t.fav = f[0] || ''; p(); });
    wc.on('dom-ready', () => cosmetic(this, t));
    // keep the floating bar from covering the bottom of the page (same trick as the .deb)
    wc.on('did-finish-load', () => { if (/^https?:/.test(wc.getURL())) wc.executeJavaScript("(function(){var b=document.body;if(b)b.style.paddingBottom='72px'})()").catch(() => {}); });
    wc.on('did-fail-load', (e, code, desc, url, main) => {
      if (!main || code === -3) return;
      wc.loadURL('supergo://error?code=' + code + '&desc=' + encodeURIComponent(desc) + '&u=' + encodeURIComponent(url)).catch(() => {});
    });
    wc.on('will-navigate', (e, url) => { if (/^supergo:/i.test(url) && !/^supergo:/i.test(wc.getURL())) e.preventDefault(); else if (/^file:/i.test(url) && !/^file:/i.test(wc.getURL())) e.preventDefault(); });
    wc.setWindowOpenHandler(d => {
      const u = d.url;
      if (!/^(https?:|about:blank)/i.test(u)) return { action: 'deny' };
      if (d.disposition === 'new-window' && d.features) return { action: 'allow', overrideBrowserWindowOptions: { autoHideMenuBar: true, icon: fs.existsSync(ICO) ? ICO : ICON, webPreferences: { sandbox: true, contextIsolation: true, nodeIntegration: false } } };
      this.newTab(u, { switch: d.disposition !== 'background-tab', pos: this.tabs.indexOf(t) + 1, priv: t.priv }); return { action: 'deny' };
    });
    wc.on('before-input-event', (e, inp) => { if (this.key(inp)) e.preventDefault(); });
    wc.on('context-menu', (e, params) => this.ctxMenu(t, params));
    wc.on('enter-html-full-screen', () => { this.fs = true; this.hideV(this.ui); this.bw.setFullScreen(true); this.layout(); this.push(); });
    wc.on('leave-html-full-screen', () => { this.fs = false; this.bw.setFullScreen(false); this.showV(this.ui); this.layout(); this.raise(); this.push(); });
    wc.on('render-process-gone', () => { wc.loadURL('supergo://error?code=-1&desc=' + encodeURIComponent('This tab crashed') + '&u=' + encodeURIComponent(t.url)).catch(() => {}); });
  }
  switchTo(t) {
    if (this.active === t) return;
    if (this.active) this.bw.removeBrowserView(this.active.view);
    this.active = t; this.bw.addBrowserView(t.view); this.layout(); this.raise(); t.wc.focus(); this.setTitle(); this.progress(!!t.loading); this.push();
  }
  closeTab(t) {
    const i = this.tabs.indexOf(t); if (i < 0) return;
    if (!this.private && !t.priv && t.url && !/^supergo:\/\/(error)/.test(t.url)) { closedTabs.push(t.url); if (closedTabs.length > 20) closedTabs.shift(); }
    this.tabs.splice(i, 1);
    if (this.active === t) { this.bw.removeBrowserView(t.view); this.active = null; }
    destroyTab(t);
    if (!this.tabs.length) { this.newTab(); return; }       // like the .deb: closing the last tab opens a fresh one
    if (!this.active) this.switchTo(this.tabs[Math.min(i, this.tabs.length - 1)]);
    this.push();
  }
  go(text) { if (this.active && text.trim()) { this.active.wc.loadURL(toUrl(text)).catch(() => {}); this.active.wc.focus(); } }
  zoom(d) { const t = this.active; if (!t) return; const f = d === 0 ? 1 : Math.max(0.3, Math.min(5, t.wc.getZoomFactor() + d)); t.wc.setZoomFactor(f); this.toast(Math.round(f * 100) + '%', 900); }
  addBookmark() {
    const t = this.active; if (!t || !/^https?:/.test(t.url)) return;
    BMS = BMS.filter(b => b.url !== t.url); BMS.push({ id: nextId++, url: t.url, title: t.title || t.url, folder: 'Bookmarks', ts: Date.now() / 1000 | 0 });
    if (BMS.length > 500) BMS = bmSorted().slice(0, 500);
    saveBms(); allPush(); this.toast('Bookmarked');
  }
  share() { const t = this.active; if (t && /^https?:/.test(t.url)) { clipboard.writeText(t.url); this.toast('Link copied'); } }
  toggleAdblock() { S.adblock = !S.adblock; saveSettings(); const t = this.active; if (t && /^https?:/.test(t.url)) t.wc.reload(); allPush(); this.toast('Ad Blocker: ' + (S.adblock ? 'On' : 'Off')); }
  clearData() {
    HIST = []; saveHist(); const ses = sessions.get('persist:supergo');
    if (ses) { ses.clearStorageData().catch(() => {}); ses.clearCache().catch(() => {}); }
    this.toast('Cleared');
  }
  openDownloads() { const d = S.download_dir || defaultDl(); try { fs.mkdirSync(d, { recursive: true }); } catch (e) {} shell.openPath(d).then(err => { if (err) this.toast("Can't open Downloads"); }); }
  openList(key) {
    const items = key === 'bm' ? bmSorted().slice(0, 500) : HIST.slice().sort((a, b) => b.ts - a.ts).slice(0, 200);
    this.ui.webContents.focus();
    this.ui.webContents.send('list', { title: key === 'bm' ? 'Bookmarks' : 'History', key, items: items.map(x => ({ t: x.title || x.url, u: x.url })) });
  }
  openTabs() { this.ui.webContents.focus(); this.ui.webContents.send('cmd', 'tabs'); }
  focusAddr() { this.ui.webContents.focus(); this.ui.webContents.send('cmd', 'focusAddr'); }
  key(i) {
    if (i.type !== 'keyDown') return false;
    const c = i.control || i.meta, k = (i.key || '').toLowerCase(), sh = i.shift, alt = i.alt, t = this.active;
    if (alt && !c) {
      if (i.key === 'ArrowLeft') { t && t.wc.goBack(); return true; }
      if (i.key === 'ArrowRight') { t && t.wc.goForward(); return true; }
      if (k === 'd') { this.focusAddr(); return true; }
      if (i.key === 'Home') { t && t.wc.loadURL(homeUrl()).catch(() => {}); return true; }
      return false;
    }
    if (i.key === 'F5') { t && (c ? t.wc.reloadIgnoringCache() : t.wc.reload()); return true; }
    if (i.key === 'F6') { this.focusAddr(); return true; }
    if (i.key === 'F12' || (c && sh && k === 'i')) { t && t.wc.openDevTools({ mode: 'detach' }); return true; }
    if (i.key === 'F11') { this.bw.setFullScreen(!this.bw.isFullScreen()); return true; }
    if (i.key === 'Escape') { if (t && t.loading) t.wc.stop(); return false; }
    if (!c) return false;
    switch (k) {
      case 'l': this.focusAddr(); return true;
      case 't': sh ? this.restoreClosed() : this.newTab(); return true;
      case 'n': sh ? this.newTab(null, { priv: true }) : new Win(false); return true;
      case 'p': sh ? this.newTab(null, { priv: true }) : (t && t.wc.print()); return true;
      case 'w': t && this.closeTab(t); return true;
      case 'q': app.quit(); return true;
      case 'r': t && (sh ? t.wc.reloadIgnoringCache() : t.wc.reload()); return true;
      case 'd': this.addBookmark(); return true;
      case 'h': this.openList('hist'); return true;
      case 'b': if (sh) { this.openList('bm'); return true; } return false;
      case 'a': if (sh) { this.openTabs(); return true; } return false;
      case 'j': this.openDownloads(); return true;
      case 'delete': if (sh) { this.clearData(); return true; } return false;
      case 'tab': case 'pagedown': case 'pageup': { const n = this.tabs.length, j = this.tabs.indexOf(this.active), back = sh || k === 'pageup'; this.switchTo(this.tabs[(j + (back ? n - 1 : 1)) % n]); return true; }
      case '=': case '+': this.zoom(0.1); return true;
      case '-': this.zoom(-0.1); return true;
      case '0': this.zoom(0); return true;
    }
    if (/^[1-9]$/.test(k)) { const x = k === '9' ? this.tabs[this.tabs.length - 1] : this.tabs[+k - 1]; if (x) this.switchTo(x); return true; }
    return false;
  }
  restoreClosed() { const u = closedTabs.pop(); if (u) this.newTab(u); }
  ctxMenu(t, p) {
    const m = new Menu(), wc = t.wc;
    const add = (label, click, enabled) => m.append(new MenuItem({ label, click, enabled: enabled !== false }));
    if (p.linkURL) { add('Open link in new tab', () => this.newTab(p.linkURL, { pos: this.tabs.indexOf(t) + 1 })); add('Copy link address', () => clipboard.writeText(p.linkURL)); m.append(new MenuItem({ type: 'separator' })); }
    if (p.mediaType === 'image' && p.srcURL) { add('Open image in new tab', () => this.newTab(p.srcURL, { pos: this.tabs.indexOf(t) + 1 })); add('Save image as…', () => wc.downloadURL(p.srcURL)); add('Copy image address', () => clipboard.writeText(p.srcURL)); m.append(new MenuItem({ type: 'separator' })); }
    if (p.isEditable) { add('Cut', () => wc.cut(), p.editFlags.canCut); add('Copy', () => wc.copy(), p.editFlags.canCopy); add('Paste', () => wc.paste(), p.editFlags.canPaste); add('Select all', () => wc.selectAll()); }
    else if (p.selectionText) { add('Copy', () => wc.copy()); add('Search "' + p.selectionText.trim().slice(0, 24) + '"', () => this.newTab(engineUrl().replace('%s', encodeURIComponent(p.selectionText.trim())), { pos: this.tabs.indexOf(t) + 1 })); }
    else { add('Back', () => wc.goBack(), wc.canGoBack()); add('Forward', () => wc.goForward(), wc.canGoForward()); add('Reload', () => wc.reload()); }
    m.append(new MenuItem({ type: 'separator' })); add('Inspect', () => { wc.inspectElement(p.x, p.y); if (wc.isDevToolsOpened()) wc.devToolsWebContents.focus(); });
    m.popup({ window: this.bw });
  }
  state() {
    const t = this.active, wc = t && t.wc, u = t ? t.url : '';
    let canBack = false, canFwd = false; try { canBack = !!wc && wc.canGoBack(); canFwd = !!wc && wc.canGoForward(); } catch (e) {}
    const su = shownUrl(u), web = /^https?:/.test(su);
    return { tabs: this.tabs.map(x => ({ id: x.id, priv: !!x.priv, title: x.title || (/^supergo:\/\/newtab/.test(x.url) ? 'New tab' : hostOf(shownUrl(x.url)) || 'New tab') })), active: t ? t.id : 0,
      url: su.startsWith('supergo://newtab') ? '' : su, host: web ? hostOf(su).replace(/^www\./, '') : (/^supergo:\/\/(?!newtab)/.test(su) ? 'SUPERGO' : ''),
      loading: !!(t && t.loading), canBack, canFwd, adblock: !!S.adblock, priv: !!(t && t.priv), vpn: vpn.state };
  }
  push() {
    if (this.t || this.bw.isDestroyed()) return;
    this.t = setTimeout(() => { this.t = null; if (!this.bw.isDestroyed() && !this.ui.webContents.isDestroyed()) this.ui.webContents.send('state', this.state()); }, 30);
  }
}
let tabSeq = 0;
function destroyTab(t) { try { if (!t.wc.isDestroyed()) { t.wc.destroy ? t.wc.destroy() : t.wc.close(); } } catch (e) {} }
const allPush = () => wins.forEach(w => w.push());

function recordVisit(w, t, url) {
  if (w.private || t.priv) return;
  const ts = Date.now() / 1000 | 0; let h = HIST.find(x => x.url === url);
  if (h) { h.ts = ts; h.visits++; } else { h = { id: nextId++, url, title: t.title || '', ts, visits: 1 }; HIST.push(h); }
  saveHist();
}
function recordTitle(w, t) { if (w.private || t.priv || !t.url) return; const h = HIST.find(x => x.url === t.url); if (h) { h.title = t.title; saveHist(); } }
function saveSession(w) { if (w.private) return; const urls = w.tabs.filter(t => !t.priv).map(t => t.url).filter(u => u && !/^supergo:\/\/error/.test(u)); writeJson('session.json', { urls, active: Math.max(0, w.tabs.filter(t => !t.priv).indexOf(w.active)) }); }

// ------------------------------------------------------------------ internal pages
function actions(name, q) {
  switch (name) {
    case 'welcomeDone': S.welcome_done = true; saveSettings(); return;
    case 'histDel': HIST = HIST.filter(h => h.id !== +q.del); saveHist(); return;
    case 'histClear': clearHistory(q.clear); return;
    case 'bmDel': BMS = BMS.filter(b => b.id !== +q.del); saveBms(); allPush(); return;
    case 'dlOpen': { const d = dls.find(x => x.id === +q.open); if (d && d.state === 'done') shell.openPath(d.path); return; }
    case 'dlShow': { const d = dls.find(x => x.id === +q.show); if (d) shell.showItemInFolder(d.path); return; }
    case 'dlClear': for (let i = dls.length - 1; i >= 0; i--) if (dls[i].state !== 'progressing') dls.splice(i, 1); return;
    case 'settings': {
      if (q.save) {
        let eng = q.engine || 'Google'; if (!ENGINES[eng] && eng !== 'Custom') eng = 'Google';
        let cust = (q.custom || '').trim(); if (!cust.includes('%s')) cust = DEFAULTS.custom_engine;
        const home = (q.home || '').trim();
        Object.assign(S, { engine: eng, custom_engine: cust, homepage: home ? toUrl(home) : 'supergo://newtab', restore: !!q.restore, adblock: !!q.adblock, anim: !!q.anim, ask_save: !!q.ask,
          download_dir: (q.ddir || '').trim() === defaultDl() ? '' : (q.ddir || '').trim(), theme: ['auto', 'dark', 'light'].includes(q.theme) ? q.theme : S.theme, weather_on: !!q.wx });
        saveSettings(); applyTheme(); allPush(); return 'Saved.';
      }
      if (q.quick && ENGINES[q.quick]) { S.engine = q.quick; saveSettings(); return 'Search engine set to ' + q.quick + '.'; }
      if (q.clear) { clearHistory(q.clear); const secs = { hour: 3600, day: 86400, week: 604800 }[q.clear]; sessions.get('persist:supergo').clearStorageData(secs ? { storages: ['cookies', 'localstorage', 'indexdb', 'cachestorage', 'serviceworkers'] } : {}).catch(() => {}); sessions.get('persist:supergo').clearCache().catch(() => {}); return 'Cleared history and site data.'; }
      if (q.resetperms) { S.perms = {}; saveSettings(); return 'Site permissions reset.'; }
      return;
    }
    case 'vpn': {
      if (q.add) { const n = v2.parseMany(q.add); if (!n.length) return 'No valid link or config found.'; n.forEach(x => S.vpn.mine.push(x.proto === 'json' ? { id: nextId++, json: JSON.stringify(x.raw), name: x.name } : { id: nextId++, uri: x.uri })); saveSettings(); return 'Added ' + n.length + ' server(s).'; }
      if (q.rm) { S.vpn.mine = S.vpn.mine.filter(x => x.id !== +q.rm); if (S.vpn.sel === +q.rm) S.vpn.sel = 'auto'; saveSettings(); return 'Removed.'; }
      if (q.use) { S.vpn.sel = q.use === 'auto' ? 'auto' : +q.use; saveSettings(); return 'Server selected.'; }
      if (q.connect) { vpnConnect(); return 'Connecting…'; }
      if (q.disconnect) { vpnStop(true); return 'Disconnected.'; }
      return;
    }
  }
}
function clearHistory(k) { const secs = { hour: 3600, day: 86400, week: 604800 }[k], lim = secs ? Date.now() / 1000 - secs : 0; HIST = HIST.filter(h => h.ts < lim); saveHist(); }
function parseMine() {
  return S.vpn.mine.map(m => { const n = m.json ? { proto: 'json', own: true, raw: JSON.parse(m.json), name: m.name, host: 'json', port: 0 } : v2.parseLink(m.uri, true); if (n) n.id = m.id; return n; }).filter(Boolean);
}
function serveInternal(req, cb, priv) {
  let name = 'newtab', q = {};
  try { const u = new URL(req.url); name = (u.hostname || u.pathname.replace(/\//g, '')).toLowerCase(); u.searchParams.forEach((v, k) => { if (!(k in q)) q[k] = v; }); } catch (e) {}
  if (name === 'api') { let sub = ''; try { sub = new URL(req.url).pathname.replace(/\//g, ''); } catch (e) {} return apiCall(sub, q).then(o => cb({ mimeType: 'application/json', data: Buffer.from(JSON.stringify(o)) }), e => cb({ mimeType: 'application/json', data: Buffer.from(JSON.stringify({ error: String(e.message || e) })) })); }
  if (name === 'logo.png') return cb({ mimeType: 'image/png', data: fs.readFileSync(ICON) });
  let html;
  try {
    if (name === 'error') html = errorPage(q, priv);
    else html = pages.render(name, q, { S, token: TOKEN, private: priv, dark: isDark, engineUrl, hist: () => HIST, bms: () => BMS, downloads: () => dls.slice().reverse(), home: homeUrl, defaultDl, version: VERSION, meta: blMeta,
      act: actions, vpn: vpnInfo });
  } catch (e) { html = '<!doctype html><meta charset=utf-8><body style="font:15px system-ui;padding:30px"><h1>Internal page error</h1><pre>' + pages.esc(String(e.stack || e)) + '</pre>'; }
  cb({ mimeType: 'text/html', data: Buffer.from(html, 'utf8') });
}

// ------------------------------------------------------------------ weather API (fetched by the app itself, honours the VPN proxy)
const WX = { data: null, ts: 0, key: '' };
function getJson(url, ses) {
  return new Promise((res, rej) => {
    const r = net.request({ url, session: ses || sessions.get('persist:supergo') || session.defaultSession, redirect: 'follow' });
    const t = setTimeout(() => { try { r.abort(); } catch (e) {} rej(new Error('timeout')); }, 9000);
    r.on('response', resp => { const ch = []; resp.on('data', c => ch.push(c)); resp.on('end', () => { clearTimeout(t); try { if (resp.statusCode !== 200) throw new Error('HTTP ' + resp.statusCode); res(JSON.parse(Buffer.concat(ch).toString('utf8'))); } catch (e) { rej(e); } }); });
    r.on('error', e => { clearTimeout(t); rej(e); }); r.end();
  });
}
async function wxLocate() {
  if (S.weather && S.weather.loc) return S.weather.loc;
  let l;
  try { const j = await getJson('https://ipwho.is/'); if (!j.success) throw 0; l = { n: j.city + ', ' + j.country, la: j.latitude, lo: j.longitude }; }
  catch (e) { const j = await getJson('https://get.geojs.io/v1/ip/geo.json'); l = { n: j.city + ', ' + j.country, la: +j.latitude, lo: +j.longitude }; }
  S.weather = Object.assign({ units: 'C' }, S.weather, { loc: l }); saveSettings(); return l;
}
async function apiCall(sub, q) {
  S.weather = S.weather && typeof S.weather === 'object' ? S.weather : { loc: null, units: 'C' };
  if (sub === 'units') { S.weather.units = S.weather.units === 'F' ? 'C' : 'F'; saveSettings(); return { ok: 1 }; }
  if (sub === 'set') { S.weather.loc = { n: String(q.n || ''), la: +q.la, lo: +q.lo }; WX.data = null; saveSettings(); return { ok: 1 }; }
  if (sub === 'find') { const j = await getJson('https://geocoding-api.open-meteo.com/v1/search?count=6&name=' + encodeURIComponent(q.q || '')); return { results: (j.results || []).map(x => ({ n: x.name + ', ' + (x.admin1 ? x.admin1 + ', ' : '') + x.country, la: x.latitude, lo: x.longitude })) }; }
  if (sub === 'wx') {
    const l = await wxLocate(), key = l.la + ',' + l.lo;
    if (!WX.data || WX.key !== key || Date.now() - WX.ts > 900000) {
      WX.data = await getJson('https://api.open-meteo.com/v1/forecast?latitude=' + l.la + '&longitude=' + l.lo + '&current=temperature_2m,weather_code,wind_speed_10m,relative_humidity_2m&daily=weather_code,temperature_2m_max,temperature_2m_min&timezone=auto&forecast_days=7');
      WX.key = key; WX.ts = Date.now();
    }
    return { loc: l, units: S.weather.units === 'F' ? 'F' : 'C', data: WX.data };
  }
  return { error: 'unknown' };
}
function errorPage(q) {
  const e = pages.esc;
  return '<!doctype html><meta charset=utf-8><meta name=viewport content="width=device-width,initial-scale=1"><title>Can\u2019t open this page</title><style>body{background:#000;color:#e5e5ea;font-family:"Segoe UI",sans-serif;text-align:center;padding:20vh 24px;margin:0}h1{font-size:20px;font-weight:600}p{color:#8e8e93;word-break:break-all}a{display:inline-block;margin-top:18px;padding:12px 26px;border-radius:22px;background:#0a84ff;color:#fff;text-decoration:none}</style><h1>Can\u2019t open this page</h1><p>' + e(q.desc || 'The page could not be loaded.') + '</p><p>' + e(q.u || '') + '</p><a href="' + e(q.u || 'supergo://newtab') + '">Try again</a>';
}

// ------------------------------------------------------------------ permissions & downloads
async function askPermission(wc, perm, cb, details, priv) {
  const ask = { geolocation: 'know your location', notifications: 'show notifications', media: 'use your camera or microphone', 'clipboard-read': 'read your clipboard', 'display-capture': 'capture your screen', midi: 'use MIDI devices' };
  if (['fullscreen', 'clipboard-sanitized-write', 'pointerLock', 'openExternal'].includes(perm)) return cb(perm !== 'openExternal');
  if (!ask[perm]) return cb(false);
  const h = hostOf(details.requestingUrl || wc.getURL()) || 'This page', key = h + '|' + perm;
  if (!priv && key in S.perms) return cb(!!S.perms[key]);
  const w = [...wins.values()].find(x => x.tabs.some(t => t.wc === wc));
  const opts = { type: 'question', buttons: ['Block', 'Allow'], defaultId: 0, cancelId: 0, title: 'SUPERGO', message: h + ' wants to ' + ask[perm] };
  const r = w ? await dialog.showMessageBox(w.bw, opts) : await dialog.showMessageBox(opts);
  const ok = r.response === 1; if (!priv) { S.perms[key] = ok; saveSettings(); } cb(ok);
}
const dls = []; let dlSeq = 0;
function uniquePath(dir, name) {
  name = name.replace(/[<>:"/\\|?*\x00-\x1f]/g, '_') || 'download'; const ext = path.extname(name), base = path.basename(name, ext); let p = path.join(dir, name), n = 1;
  while (fs.existsSync(p)) p = path.join(dir, base + ' (' + (n++) + ')' + ext);
  return p;
}
function onDownload(ses, e, item) {
  const d = { id: ++dlSeq, name: item.getFilename(), path: '', state: 'progressing', status: 'starting…' };
  dls.push(d);
  if (!S.ask_save) { const dir = S.download_dir || defaultDl(); try { fs.mkdirSync(dir, { recursive: true }); } catch (x) {} d.path = uniquePath(dir, item.getFilename()); item.setSavePath(d.path); }
  const upd = () => { const tot = item.getTotalBytes(), rec = item.getReceivedBytes(); d.status = d.state === 'progressing' ? (tot ? Math.round(rec * 100 / tot) + '% of ' + fmt(tot) : fmt(rec)) : d.state === 'done' ? 'done · ' + fmt(rec) : d.state; d.path = item.getSavePath() || d.path; d.name = path.basename(d.path) || d.name; };
  item.on('updated', () => { d.state = 'progressing'; upd(); });
  item.once('done', (ev, st) => { d.state = st === 'completed' ? 'done' : st; upd(); });
}
const fmt = n => n >= 1e9 ? (n / 1e9).toFixed(1) + ' GB' : n >= 1e6 ? (n / 1e6).toFixed(1) + ' MB' : n >= 1e3 ? (n / 1e3).toFixed(0) + ' KB' : n + ' B';

// ------------------------------------------------------------------ uBlock-style filtering
const BL = { hosts: new Set(), hosts3p: new Set(), paths: [], cosGeneric: '', cosBy: {}, ready: false };
let blMeta = {}; const blockedCount = new Map();
function loadBlocklist() {
  try {
    blMeta = JSON.parse(fs.readFileSync(path.join(__dirname, 'filters', 'blocklist.meta.json'), 'utf8'));
    const j = JSON.parse(zlib.gunzipSync(fs.readFileSync(path.join(__dirname, 'filters', 'blocklist.json.gz'))).toString('utf8'));
    BL.hosts = new Set(j.hosts); BL.hosts3p = new Set(j.hosts3p);
    const ok = []; j.paths3p.forEach(p => { try { new RegExp(p); ok.push(p); } catch (e) {} });
    for (let i = 0; i < ok.length; i += 80) { try { BL.paths.push(new RegExp(ok.slice(i, i + 80).join('|'), 'i')); } catch (e) {} }
    BL.cosGeneric = j.cosGeneric.map(s => s + '{display:none!important}').join('\n');
    BL.cosBy = j.cosBy; BL.ready = true;
  } catch (e) { console.error('blocklist', e); }
}
const suffixHit = (h, set) => { while (h) { if (set.has(h)) return true; const i = h.indexOf('.'); if (i < 0) return false; h = h.slice(i + 1); } return false; };
const base2 = h => { const p = h.split('.'); if (p.length <= 2) return h; const l = p[p.length - 1], s = p[p.length - 2]; return (l.length === 2 && ['co', 'com', 'org', 'net', 'gov', 'ac', 'edu'].includes(s)) ? p.slice(-3).join('.') : p.slice(-2).join('.'); };
function siteBlockOn(u) { const h = hostOf(u); return !!h && !S.adblock_off.includes(h); }
function attachAdblock(ses) {
  ses.webRequest.onBeforeRequest({ urls: ['http://*/*', 'https://*/*', 'ws://*/*', 'wss://*/*'] }, (d, cb) => {
    if (!S.adblock || !BL.ready || d.resourceType === 'mainFrame') return cb({});
    let top = ''; try { top = d.webContents ? d.webContents.getURL() : (d.referrer || ''); } catch (e) {}
    const th = hostOf(top);
    if (th && S.adblock_off.includes(th)) return cb({});
    let h; try { h = new URL(d.url).hostname; } catch (e) { return cb({}); }
    let hit = suffixHit(h, BL.hosts);
    const third = !!th && base2(h) !== base2(th);
    if (!hit && third) { hit = suffixHit(h, BL.hosts3p); if (!hit) for (const r of BL.paths) if (r.test(d.url)) { hit = true; break; } }
    if (hit) { if (d.webContentsId) blockedCount.set(d.webContentsId, (blockedCount.get(d.webContentsId) || 0) + 1); return cb({ cancel: true }); }
    cb({});
  });
}
function cosmetic(w, t) {
  if (!S.adblock || !BL.ready || t.wc.isDestroyed()) return;
  const u = t.wc.getURL(); if (!/^https?:/.test(u)) return;
  let h = hostOf(u); if (S.adblock_off.includes(h)) return;
  let css = BL.cosGeneric; const by = [];
  for (let x = h; x; ) { if (BL.cosBy[x]) by.push(...BL.cosBy[x]); const i = x.indexOf('.'); if (i < 0) break; x = x.slice(i + 1); }
  if (by.length) css += '\n' + by.map(s => s + '{display:none!important}').join('\n');
  if (css) t.wc.insertCSS(css, { cssOrigin: 'user' }).catch(() => {});
}

// ------------------------------------------------------------------ VPN (xray / v2ray, browser only)
const vpn = { state: 'off', text: 'Off', proc: null, port: 0, gen: 0, core: null, builtin: null };
const coreDirs = () => [path.join(path.dirname(process.execPath), 'vpn'), path.join(__dirname, 'vpn'), path.join(UD, 'vpn')];
function vpnInfo() { return { state: vpn.state, text: vpn.text, sel: S.vpn.sel, mine: parseMine(), core: vpn.core ? path.basename(vpn.core.file) + ' ' + vpn.core.ver.join('.') : '', coreDir: path.join(UD, 'vpn') }; }
function applyProxy(ses) {
  const cfg = vpn.state === 'on' ? { proxyRules: 'socks5://127.0.0.1:' + vpn.port, proxyBypassRules: '<local>' } : vpn.state === 'dropped' ? { proxyRules: 'socks5://127.0.0.1:9', proxyBypassRules: '<local>' } : { mode: 'system' };
  ses.setProxy(cfg).catch(() => {});
}
function vpnChanged(state, text) {
  vpn.state = state; vpn.text = text;
  sessions.forEach(applyProxy);
  wins.forEach(w => w.tabs.forEach(t => { try { t.wc.setWebRTCIPHandlingPolicy(state === 'off' ? 'default_public_interface_only' : 'disable_non_proxied_udp'); } catch (e) {} }));
  allPush();
}
function vpnStop(user) {
  vpn.gen++; if (vpn.proc) { const p = vpn.proc; vpn.proc = null; try { p.kill(); } catch (e) {} }
  vpnChanged('off', user ? 'Off' : vpn.text);
}
async function vpnConnect() {
  if (vpn.state === 'connecting') return;
  vpnStop(true); const gen = ++vpn.gen; vpnChanged('connecting', 'Finding the core…');
  const say = t => { if (gen === vpn.gen) { vpn.text = t; allPush(); } };
  const fail = t => { if (gen === vpn.gen) vpnChanged('off', 'Failed: ' + t); };
  try {
    const core = vpn.core = await v2.findCore(coreDirs());
    if (!core) return fail('xray.exe not found. Put xray.exe in ' + path.join(UD, 'vpn') + ' (see README).');
    let nodes;
    if (S.vpn.sel === 'auto') {
      say('Testing servers…');
      if (!vpn.builtin) vpn.builtin = v2.loadBuiltin(path.join(__dirname, 'vpn', 'servers.tsv.gz'));
      const usable = vpn.builtin.filter(n => !/q/.test(n.caps) && (core.kind === 'xray' || !/[rx]/.test(n.caps)));
      const sample = []; for (let i = 0; i < 160 && usable.length; i++) sample.push(usable[Math.random() * usable.length | 0]);
      const probed = (await v2.tcpProbe(sample, 2500, 60)).sort((a, b) => a[0] - b[0]).slice(0, 8);
      nodes = probed.map(p => v2.parseLink(p[1].uri, false)).filter(Boolean);
      if (!nodes.length) return fail('no reachable public server found');
    } else {
      const n = parseMine().find(x => x.id === S.vpn.sel); if (!n) return fail('selected server not found');
      nodes = [n];
    }
    fs.mkdirSync(path.join(UD, 'vpn'), { recursive: true });
    for (let i = 0; i < nodes.length; i++) {
      if (gen !== vpn.gen) return;
      const n = nodes[i]; say('Connecting (' + (i + 1) + '/' + nodes.length + ') ' + n.name);
      const port = await v2.freePort(), cfgPath = path.join(UD, 'vpn', 'run-' + gen + '-' + i + '.json');
      fs.writeFileSync(cfgPath, JSON.stringify(v2.buildConfig(n, port, core)), { mode: 0o600 });
      const proc = v2.startCore(core, cfgPath);
      const up = await v2.waitListen(port, proc, 6000);
      try { fs.unlinkSync(cfgPath); } catch (e) {}
      if (gen !== vpn.gen) { try { proc.kill(); } catch (e) {} return; }
      const ms = up ? await v2.tunnelCheck(port, 9000) : null;
      if (ms == null) { try { proc.kill(); } catch (e) {} if (nodes.length === 1) return fail(v2.hintFromLog(proc.log) || 'the server did not pass traffic'); continue; }
      vpn.proc = proc; vpn.port = port;
      proc.once('exit', () => { if (vpn.proc === proc && gen === vpn.gen) { vpn.proc = null; vpnChanged('dropped', 'Connection dropped - browsing is blocked until you reconnect or turn the VPN off'); } });
      return vpnChanged('on', 'Connected via ' + n.name + ' (' + ms + ' ms)');
    }
    fail('none of the tested servers worked');
  } catch (e) { fail(String(e.message || e)); }
}

// ------------------------------------------------------------------ native menus & IPC
ipcMain.on('sg', (e, cmd, a) => {
  const w = uiWins.get(e.sender.id); if (!w || w.bw.isDestroyed()) return;
  const t = w.active;
  switch (cmd) {
    case 'ready': w.push(); break;
    case 'mode': w.mode = a === 'full' ? 'full' : 'bar'; w.layoutUi(); if (w.mode === 'full') w.ui.webContents.focus(); else if (t) t.wc.focus(); break;
    case 'focusPage': t && t.wc.focus(); break;
    case 'back': t && t.wc.goBack(); break;
    case 'fwd': t && t.wc.goForward(); break;
    case 'reload': t && (t.loading ? t.wc.stop() : t.wc.reload()); break;
    case 'go': if (typeof a === 'string') w.go(a); break;
    case 'newtab': w.newTab(); break;
    case 'newpriv': w.newTab(null, { priv: true }); break;
    case 'tab': { const x = w.tabs.find(z => z.id === a); if (x) w.switchTo(x); break; }
    case 'closetab': { const x = w.tabs.find(z => z.id === a); if (x) w.closeTab(x); break; }
    case 'share': w.share(); break;
    case 'addbm': w.addBookmark(); break;
    case 'adblock': w.toggleAdblock(); break;
    case 'clear': w.clearData(); break;
    case 'downloads': w.openDownloads(); break;
    case 'list': if (a === 'bm' || a === 'hist') w.openList(a); break;
    case 'clearlist': if (a === 'bm') { BMS = []; saveBms(); } else if (a === 'hist') { HIST = []; saveHist(); } allPush(); w.toast('Cleared'); break;
    case 'openurl': if (typeof a === 'string' && /^https?:/.test(a) && t) t.wc.loadURL(a).catch(() => {}); break;
    case 'open2': if (['settings', 'vpn'].includes(a)) w.newTab('supergo://' + a); break;
  }
});
nativeTheme.on('updated', allPush);

// ------------------------------------------------------------------ startup
function openUrlsFrom(argv) {
  const urls = argv.filter(a => /^(https?:\/\/|file:\/\/)/i.test(a)), priv = argv.includes('--private');
  return { urls, priv };
}
app.on('second-instance', (e, argv) => {
  const { urls, priv } = openUrlsFrom(argv.slice(1));
  if (priv || !lastWin || lastWin.bw.isDestroyed()) { new Win(priv, urls); return; }
  urls.length ? urls.forEach(u => lastWin.newTab(u)) : lastWin.newTab();
  if (lastWin.bw.isMinimized()) lastWin.bw.restore(); lastWin.bw.focus();
});
app.on('window-all-closed', () => app.quit());
app.on('before-quit', () => { if (lastWin && !lastWin.bw.isDestroyed()) saveSession(lastWin); try { clearTimeout(hT); writeJson('history.json', HIST.slice(-5000)); } catch (e) {} if (vpn.proc) try { vpn.proc.kill(); } catch (e) {} });
app.on('web-contents-created', (e, wc) => { wc.on('will-attach-webview', ev => ev.preventDefault()); });

app.whenReady().then(() => {
  loadSettings(); loadData(); applyTheme();
  // never leave stale VPN config files behind
  try { const d = path.join(UD, 'vpn'); fs.readdirSync(d).filter(f => /^run-.*\.json$/.test(f)).forEach(f => fs.unlinkSync(path.join(d, f))); } catch (e) {}
  setTimeout(loadBlocklist, 50);
  const { urls, priv } = openUrlsFrom(process.argv.slice(1));
  let start = urls;
  if (!urls.length && S.restore && !priv) { const s = readJson('session.json', null); if (s && Array.isArray(s.urls) && s.urls.length) start = s.urls.filter(u => /^(https?|supergo|file):/.test(u)).slice(0, 40); }
  const w = new Win(priv, start.length ? start : null);
});
