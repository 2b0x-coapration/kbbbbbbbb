'use strict';
// SUPERGO v2ray / xray backend. Parses share links, writes a core config with ONE local SOCKS5 inbound on
// 127.0.0.1, runs xray/v2ray as the normal user. Only the browser is pointed at that port.
const fs = require('fs'), path = require('path'), net = require('net'), zlib = require('zlib');
const { execFile, spawn } = require('child_process');

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const LINK_RE = /(?:vless|vmess|trojan|ss):\/\/[^\s<>"']+/gi;
const PRIVATE_NETS = ['127.0.0.0/8', '10.0.0.0/8', '172.16.0.0/12', '192.168.0.0/16', '169.254.0.0/16', '100.64.0.0/10', '::1/128', 'fc00::/7', 'fe80::/10'];
const NETS = ['tcp', 'ws', 'grpc', 'http', 'httpupgrade', 'xhttp', 'kcp', 'quic'];

function b64d(s) {
  s = s.trim().replace(/-/g, '+').replace(/_/g, '/');
  s += '='.repeat((4 - s.length % 4) % 4);
  return Buffer.from(s, 'base64').toString('utf8');
}
function dec(s) { try { return decodeURIComponent(s); } catch (e) { return s; } }
function flagCC(text) {
  const m = /([\u{1F1E6}-\u{1F1FF}])([\u{1F1E6}-\u{1F1FF}])/u.exec(text || '');
  if (m) return String.fromCharCode(m[1].codePointAt(0) - 0x1F1E6 + 65, m[2].codePointAt(0) - 0x1F1E6 + 65);
  return '';
}
function splitHostPort(netloc) {
  const hp = netloc.slice(netloc.lastIndexOf('@') + 1);
  let h, p;
  if (hp.startsWith('[')) { const i = hp.indexOf(']'); h = hp.slice(1, i); p = hp.slice(i + 1).replace(/^:/, ''); }
  else { const i = hp.lastIndexOf(':'); h = hp.slice(0, i); p = hp.slice(i + 1); }
  p = parseInt(p, 10);
  if (!h || !(p > 0 && p < 65536)) return [null, null];
  return [h, p];
}
function cleanLink(s) {
  s = s.trim().replace(/&amp;/g, '&');
  s = s.split(/<|‏/)[0];
  return s.trim();
}
function parseURL(link) {
  // WHATWG URL fails on some schemes' host forms; do a manual split instead.
  const m = /^([a-z]+):\/\/([^/?#]*)([^?#]*)(?:\?([^#]*))?(?:#(.*))?$/i.exec(link);
  if (!m) return null;
  const qs = {};
  (m[4] || '').split('&').forEach(kv => { if (!kv) return; const i = kv.indexOf('='); const k = dec(i < 0 ? kv : kv.slice(0, i)); const v = i < 0 ? '' : kv.slice(i + 1); if (!(k in qs)) qs[k] = dec(v); });
  return { scheme: m[1].toLowerCase(), netloc: m[2], path: m[3], qs, frag: dec(m[5] || '') };
}
function q(qs, k, d) { const v = qs[k] !== undefined ? qs[k] : qs[k.toLowerCase()]; return (v === undefined ? (d || '') : v).trim(); }

function parseVless(link, proto) {
  const u = parseURL(link); if (!u || u.netloc.indexOf('@') < 0) return null;
  const [host, port] = splitHostPort(u.netloc); if (!host) return null;
  const ident = dec(u.netloc.slice(0, u.netloc.lastIndexOf('@')));
  if (proto === 'vless' && !UUID_RE.test(ident)) return null;
  let net = q(u.qs, 'type', 'tcp').toLowerCase();
  net = { raw: 'tcp', h2: 'http', splithttp: 'xhttp' }[net] || net;
  let sec = q(u.qs, 'security', proto === 'trojan' ? 'tls' : 'none').toLowerCase();
  if (!['none', 'tls', 'reality'].includes(sec)) sec = 'none';
  if (!NETS.includes(net)) return null;
  let flow = q(u.qs, 'flow'); if (!flow.startsWith('xtls-rprx-vision')) flow = '';
  let extra = {}; try { const e = JSON.parse(q(u.qs, 'extra') || '{}'); if (e && typeof e === 'object') extra = e; } catch (e) {}
  const ins = v => v === '1' || v === 'true';
  return { name: u.frag.trim(), host, port, id: ident, net, sec, flow, sni: q(u.qs, 'sni') || q(u.qs, 'peer'), fp: q(u.qs, 'fp'),
    alpn: q(u.qs, 'alpn'), path: q(u.qs, 'path'), hosthdr: q(u.qs, 'host'), service: q(u.qs, 'serviceName'), mode: q(u.qs, 'mode'),
    pbk: q(u.qs, 'pbk'), sid: q(u.qs, 'sid'), spx: q(u.qs, 'spx'), htype: q(u.qs, 'headerType', 'none').toLowerCase(),
    seed: q(u.qs, 'seed'), insecure: ins(q(u.qs, 'allowInsecure')) || ins(q(u.qs, 'insecure')), extra };
}
function parseVmess(link) {
  const j = JSON.parse(b64d(link.slice(8).split('#')[0]));
  const host = j.add, port = parseInt(j.port, 10);
  if (!host || !UUID_RE.test(j.id || '') || !(port > 0 && port < 65536)) return null;
  let net = String(j.net || 'tcp').toLowerCase(); net = { h2: 'http', raw: 'tcp', splithttp: 'xhttp' }[net] || net;
  if (!NETS.includes(net)) return null;
  const sec = String(j.tls || '').toLowerCase() === 'tls' ? 'tls' : 'none';
  return { name: String(j.ps || ''), host, port, id: j.id, aid: parseInt(j.aid || 0, 10), scy: j.scy || 'auto', net, sec, flow: '',
    sni: j.sni || j.host || '', fp: j.fp || '', alpn: j.alpn || '', path: j.path || '', hosthdr: j.host || '', service: j.path || '',
    mode: '', pbk: '', sid: '', spx: '', htype: String(j.type || 'none').toLowerCase(), seed: j.seed || '', insecure: false, extra: {} };
}
function parseSS(link) {
  let body = link.slice(5), frag = '';
  const hi = body.indexOf('#'); if (hi >= 0) { frag = dec(body.slice(hi + 1)); body = body.slice(0, hi); }
  let query = ''; const qi = body.indexOf('?'); if (qi >= 0) { query = body.slice(qi + 1); body = body.slice(0, qi); }
  let cred, hp;
  if (body.includes('@')) { const i = body.lastIndexOf('@'); cred = body.slice(0, i); hp = body.slice(i + 1); cred = cred.includes(':') ? dec(cred) : b64d(cred); }
  else { const d = b64d(body); const i = d.lastIndexOf('@'); cred = d.slice(0, i); hp = d.slice(i + 1); }
  const ci = cred.indexOf(':'); const method = cred.slice(0, ci), pw = cred.slice(ci + 1);
  const [host, port] = splitHostPort('x@' + hp);
  if (!(host && port && method && pw)) return null;
  if (/(^|&)plugin=/.test(query)) return null;
  return { name: frag.trim(), host, port, id: pw, method, net: 'tcp', sec: 'none', flow: '', sni: '', fp: '', alpn: '', path: '', hosthdr: '',
    service: '', mode: '', pbk: '', sid: '', spx: '', htype: 'none', seed: '', insecure: false, extra: {} };
}
function parseLink(text, own) {
  const link = cleanLink(text);
  const m = /^(vless|vmess|trojan|ss):\/\//i.exec(link); if (!m) return null;
  const proto = m[1].toLowerCase();
  let n;
  try { n = proto === 'vmess' ? parseVmess(link) : proto === 'ss' ? parseSS(link) : parseVless(link, proto); } catch (e) { return null; }
  if (!n) return null;
  n.proto = proto; n.own = !!own; n.uri = link; n.cc = flagCC(n.name);
  n.name = (n.name || n.host + ':' + n.port).slice(0, 70);
  return n;
}
function parseJsonConfig(text, name) {
  let j; try { j = JSON.parse(text); } catch (e) { return null; }
  const obs = j && (j.outbounds || (j.outbound ? [j.outbound] : null));
  if (!Array.isArray(obs) || !obs.length) return null;
  return { proto: 'json', own: true, raw: j, name: (name || 'JSON config').slice(0, 70), host: 'json', port: 0, uri: '', cc: '', net: 'tcp', sec: 'none' };
}
function parseMany(text) {
  const out = [], seen = new Set();
  const t = (text || '').trim();
  if (t.startsWith('{')) { const n = parseJsonConfig(t); return n ? [n] : []; }
  let blob = t;
  if (!/^(vless|vmess|trojan|ss):\/\//im.test(blob)) { try { const d = b64d(blob); if (/(vless|vmess|trojan|ss):\/\//i.test(d)) blob = d; } catch (e) {} }
  (blob.match(LINK_RE) || []).forEach(l => { const n = parseLink(l, true); if (n && !seen.has(n.uri)) { seen.add(n.uri); out.push(n); } });
  return out;
}

// ---- core config
function tlsBlock(n, sec) {
  const sni = n.sni || n.hosthdr || '';
  if (sec === 'reality') return ['realitySettings', { serverName: sni, fingerprint: n.fp || 'chrome', publicKey: n.pbk || '', shortId: n.sid || '', spiderX: n.spx || '' }];
  const t = { allowInsecure: !!(n.insecure && n.own) };
  if (sni) t.serverName = sni;
  if (n.alpn) t.alpn = n.alpn.split(',').filter(Boolean);
  if (n.fp) t.fingerprint = n.fp;
  return ['tlsSettings', t];
}
function streamSettings(n, core) {
  const net = n.net, sec = n.sec, s = { network: net, security: sec };
  const hh = n.hosthdr || '', p = n.path || '/';
  if (net === 'tcp') {
    if (n.htype === 'http') s.tcpSettings = { header: { type: 'http', request: { version: '1.1', method: 'GET', path: p.split(',').filter(Boolean), headers: { Host: hh.split(',').filter(Boolean) } } } };
  } else if (net === 'ws') { const ws = { path: p }; if (hh) { ws.headers = { Host: hh }; ws.host = hh; } s.wsSettings = ws; }
  else if (net === 'grpc') s.grpcSettings = { serviceName: n.service || '', multiMode: n.mode === 'multi' };
  else if (net === 'http') s.httpSettings = { path: p, host: hh.split(',').filter(Boolean) };
  else if (net === 'httpupgrade') s.httpupgradeSettings = { path: p, host: hh };
  else if (net === 'xhttp') {
    const x = { path: p, host: hh, mode: n.mode || 'auto' }; if (n.extra && Object.keys(n.extra).length) x.extra = n.extra;
    if (core.xhttpName) s.xhttpSettings = x; else { s.network = 'splithttp'; s.splithttpSettings = x; }
  } else if (net === 'kcp') s.kcpSettings = { header: { type: n.htype || 'none' }, seed: n.seed || '' };
  else if (net === 'quic') s.quicSettings = { security: 'none', header: { type: n.htype || 'none' } };
  if (sec === 'tls' || sec === 'reality') { const [k, v] = tlsBlock(n, sec); s[k] = v; }
  return s;
}
function outbound(n, core) {
  const p = n.proto; let st;
  if (p === 'vless') { const user = { id: n.id, encryption: 'none' }; if (n.flow && core.kind === 'xray') user.flow = n.flow; st = { vnext: [{ address: n.host, port: n.port, users: [user] }] }; }
  else if (p === 'vmess') st = { vnext: [{ address: n.host, port: n.port, users: [{ id: n.id, alterId: n.aid || 0, security: n.scy || 'auto' }] }] };
  else if (p === 'trojan') st = { servers: [{ address: n.host, port: n.port, password: n.id }] };
  else st = { servers: [{ address: n.host, port: n.port, method: n.method, password: n.id }] };
  const ob = { tag: 'proxy', protocol: p === 'ss' ? 'shadowsocks' : p, settings: st };
  if (p !== 'ss') ob.streamSettings = streamSettings(n, core);
  return ob;
}
function buildConfig(n, port, core) {
  const inbound = { tag: 'in', listen: '127.0.0.1', port, protocol: 'socks', settings: { auth: 'noauth', udp: false } };
  const block = { tag: 'block', protocol: 'blackhole', settings: {} };
  const rules = [{ type: 'field', ip: PRIVATE_NETS, outboundTag: 'block' }];
  if (n.proto === 'json') {
    const j = JSON.parse(JSON.stringify(n.raw)); let obs = j.outbounds || [j.outbound];
    if (!obs.some(o => o.tag === 'block')) obs = obs.concat([block]);
    const cfg = { log: { loglevel: 'warning' }, inbounds: [inbound], outbounds: obs };
    if (j.dns) cfg.dns = j.dns;
    const r = j.routing || {};
    cfg.routing = { domainStrategy: r.domainStrategy || 'AsIs', rules: rules.concat((r.rules || []).filter(x => x && typeof x === 'object')) };
    return cfg;
  }
  return { log: { loglevel: 'warning' }, inbounds: [inbound], outbounds: [outbound(n, core), block], routing: { domainStrategy: 'AsIs', rules } };
}

// ---- core discovery / process
function version(file) {
  return new Promise(res => execFile(file, ['version'], { timeout: 6000, windowsHide: true }, (err, out) => {
    const m = /(Xray|V2Ray)\s+v?(\d+)\.(\d+)\.(\d+)/i.exec(String(out || ''));
    res(m ? { kind: m[1].toLowerCase(), ver: [+m[2], +m[3], +m[4]] } : null);
  }));
}
async function findCore(dirs) {
  for (const name of ['xray.exe', 'v2ray.exe', 'xray', 'v2ray']) for (const d of dirs) {
    const f = path.join(d, name);
    if (fs.existsSync(f)) {
      const v = await version(f);
      if (v) { const [a, b, c] = v.ver; return { file: f, kind: v.kind, ver: v.ver, xhttpName: v.kind === 'xray' && (a > 1 || b > 8 || (b === 8 && c >= 24)) }; }
    }
  }
  return null;
}
function freePort() {
  return new Promise((res, rej) => { const s = net.createServer(); s.listen(0, '127.0.0.1', () => { const p = s.address().port; s.close(() => res(p)); }); s.on('error', rej); });
}
function waitListen(port, proc, ms) {
  return new Promise(res => {
    const t0 = Date.now();
    (function tick() {
      if (proc.exitCode !== null) return res(false);
      const c = net.connect(port, '127.0.0.1'); c.once('connect', () => { c.destroy(); res(true); });
      c.once('error', () => { c.destroy(); Date.now() - t0 > ms ? res(false) : setTimeout(tick, 150); });
    })();
  });
}
// Real end-to-end test: HTTP request through the SOCKS5 port. Resolves round-trip ms or null.
function tunnelCheck(port, timeout) {
  return new Promise(res => {
    const t0 = Date.now(); const host = Buffer.from('cp.cloudflare.com'); let stage = 0, done = false;
    const s = net.connect(port, '127.0.0.1');
    const fin = v => { if (!done) { done = true; s.destroy(); res(v); } };
    s.setTimeout(timeout || 9000, () => fin(null)); s.on('error', () => fin(null));
    s.on('connect', () => s.write(Buffer.from([5, 1, 0])));
    s.on('data', d => {
      if (stage === 0) { if (d[0] === 5 && d[1] === 0) { stage = 1; s.write(Buffer.concat([Buffer.from([5, 1, 0, 3, host.length]), host, Buffer.from([0, 80])])); } else fin(null); }
      else if (stage === 1) { if (d[1] === 0) { stage = 2; s.write('GET /generate_204 HTTP/1.1\r\nHost: cp.cloudflare.com\r\nConnection: close\r\n\r\n'); } else fin(null); }
      else fin(d.toString('latin1').startsWith('HTTP/') ? Date.now() - t0 : null);
    });
  });
}
function tcpProbe(nodes, timeout, workers) {
  return new Promise(res => {
    const out = []; let i = 0, active = 0;
    const next = () => {
      if (i >= nodes.length && active === 0) return res(out);
      while (active < workers && i < nodes.length) {
        const n = nodes[i++]; active++; const t0 = Date.now();
        const c = net.connect({ host: n.host, port: n.port });
        const end = ok => { c.destroy(); active--; if (ok) out.push([Date.now() - t0, n]); next(); };
        c.setTimeout(timeout, () => end(false)); c.once('connect', () => end(true)); c.once('error', () => end(false));
      }
    };
    next();
  });
}
function loadBuiltin(file) {
  const out = [];
  try {
    zlib.gunzipSync(fs.readFileSync(file)).toString('utf8').split('\n').forEach(ln => {
      const p = ln.split('\t');
      if (p.length === 5) out.push({ caps: p[0] === '-' ? '' : p[0], host: p[1], port: +p[2], sec: p[3], uri: p[4], own: false });
    });
  } catch (e) {}
  return out;
}
function startCore(core, cfgPath) {
  const p = spawn(core.file, ['run', '-c', cfgPath], { windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'], cwd: path.dirname(core.file) });
  p.log = [];
  const grab = d => { p.log.push(...String(d).split(/\r?\n/).filter(Boolean)); if (p.log.length > 60) p.log.splice(0, p.log.length - 60); };
  p.stdout.on('data', grab); p.stderr.on('data', grab);
  return p;
}
function hintFromLog(lines) {
  const t = lines.slice(-40).join('\n').toLowerCase();
  for (const [k, v] of [['reality', 'this core cannot run Reality - use xray'], ['failed to parse', 'the core rejected the config'], ['address already in use', 'local port clash'],
    ['connection refused', 'the server refused the connection'], ['i/o timeout', 'the server did not answer'], ['tls', 'TLS handshake failed'], ['no such host', 'the server name does not resolve'], ['geoip', 'geoip.dat is missing']])
    if (t.includes(k)) return v;
  return '';
}

module.exports = { parseLink, parseMany, buildConfig, findCore, freePort, waitListen, tunnelCheck, tcpProbe, loadBuiltin, startCore, hintFromLog };
