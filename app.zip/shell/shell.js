'use strict';
(function () {
  var $ = function (i) { return document.getElementById(i); };
  var st = null, editing = false, popOpen = false, dlgOpen = false;
  var scrim = $('scrim'), pop = $('pop'), dlg = $('dlg');
  function send(c, a) { window.sg.send(c, a); }
  function el(tag, cls, txt) { var e = document.createElement(tag); if (cls) e.className = cls; if (txt != null) e.textContent = txt; return e; }

  var RELOAD = '<path d="M18.578 9.606A7 7 0 1 1 9.606 5.422" fill="none"/><path class="ar" d="M13.553 3.986L10.837 8.805L8.375 2.039Z"/>';
  var STOP = '<path d="M6.5 6.5L17.5 17.5M17.5 6.5L6.5 17.5" fill="none"/>';

  // ---- overlay mode: the view is only as big as the bar until a popover / dialog needs the whole window
  function open(fn) {
    send('mode', 'full');
    var done = false;
    function go() { if (done) return; done = true; window.removeEventListener('resize', go); fn(); }
    window.addEventListener('resize', go);
    setTimeout(go, 140);
  }
  function hideAll() { pop.hidden = true; dlg.hidden = true; scrim.hidden = true; popOpen = dlgOpen = false; }
  function closeAll() { if (!popOpen && !dlgOpen) return; hideAll(); send('mode', 'bar'); }
  scrim.onmousedown = function (e) { e.preventDefault(); closeAll(); };
  dlg.onmousedown = function (e) { if (e.target === dlg) e.preventDefault(); };

  function place(anchor) {
    pop.hidden = false; scrim.hidden = false; popOpen = true;
    var r = anchor.getBoundingClientRect(), w = pop.offsetWidth;
    pop.style.left = Math.max(8, Math.min(window.innerWidth - w - 8, r.left + r.width / 2 - w / 2)) + 'px';
    pop.style.bottom = (window.innerHeight - $('bar').getBoundingClientRect().top + 6) + 'px';
  }
  function item(label, fn, cls) {
    var b = el('button', 'mitem' + (cls ? ' ' + cls : ''), label);
    b.onclick = fn; return b;
  }

  // ---- menu popover (same items as the .deb) + two Windows-only extras at the bottom
  function showMenu() {
    open(function () {
      pop.textContent = ''; pop.className = 'pop menu';
      var run = function (c, a) { return function () { closeAll(); send(c, a); }; };
      pop.appendChild(item('New Tab', run('newtab')));
      pop.appendChild(item('New Private Tab', run('newpriv')));
      pop.appendChild(item('Add Bookmark', run('addbm')));
      pop.appendChild(item('History', function () { hideAll(); send('list', 'hist'); }));
      pop.appendChild(item('Downloads', run('downloads')));
      pop.appendChild(item('Ad Blocker: ' + (st && st.adblock ? 'On' : 'Off'), run('adblock')));
      pop.appendChild(item('Clear History and Data', run('clear')));
      pop.appendChild(item('VPN' + (st && st.vpn === 'on' ? ': On' : ''), run('open2', 'vpn')));
      pop.appendChild(item('Settings', run('open2', 'settings')));
      place($('b-menu'));
    });
  }

  // ---- tabs popover
  function showTabs() {
    open(function () {
      pop.textContent = ''; pop.className = 'pop tabs';
      var n = st.tabs.length;
      pop.appendChild(el('div', 'pophead', n + ' ' + (n === 1 ? 'Tab' : 'Tabs')));
      var list = el('div', 'tlist');
      st.tabs.forEach(function (t) {
        var cur = t.id === st.active, row = el('div', 'trow');
        var b = item((cur ? '\u25CF  ' : '     ') + (t.priv ? 'Private \u2022 ' : '') + t.title, function () { closeAll(); send('tab', t.id); }, cur ? 'current' : '');
        var x = el('button', 'xbtn', '\u2715'); x.title = 'Close tab';
        x.onclick = function () { closeAll(); send('closetab', t.id); };
        row.appendChild(b); row.appendChild(x); list.appendChild(row);
      });
      pop.appendChild(list);
      var foot = el('div', 'tfoot');
      var nb = el('button', 'btn primary', 'New tab'); nb.onclick = function () { closeAll(); send('newtab'); };
      var cb = el('button', 'btn', 'Close tab'); cb.onclick = function () { closeAll(); send('closetab', st.active); };
      foot.appendChild(nb); foot.appendChild(cb); pop.appendChild(foot);
      place($('b-tabs'));
      var cr = list.querySelector('.current'); if (cr) cr.scrollIntoView({ block: 'nearest' });
    });
  }

  // ---- history / bookmarks list dialog
  function showList(p) {
    open(function () {
      dlg.textContent = '';
      var d = el('div', 'dlg');
      d.appendChild(el('div', 'dhead', p.title));
      var body = el('div', 'dbody');
      if (!p.items.length) body.appendChild(el('div', 'empty', 'Nothing here yet'));
      p.items.forEach(function (it) {
        var r = el('div', 'lrow'); r.appendChild(el('div', 'l1', it.t)); r.appendChild(el('div', 'l2', it.u));
        r.onclick = function () { closeAll(); send('openurl', it.u); };
        body.appendChild(r);
      });
      d.appendChild(body);
      var foot = el('div', 'dfoot');
      var clr = el('button', 'btn', 'Clear'); clr.onclick = function () { closeAll(); send('clearlist', p.key); };
      var cls = el('button', 'btn', 'Close'); cls.onclick = closeAll;
      foot.appendChild(clr); foot.appendChild(cls); d.appendChild(foot);
      dlg.appendChild(d); dlg.hidden = false; dlgOpen = true;
    });
  }

  // ---- address pill
  function beginEdit() {
    if (editing || !st) return; editing = true;
    $('hostbox').hidden = true; $('entry').hidden = false;
    $('entry').value = st.url || ''; $('entry').focus(); $('entry').select();
  }
  function endEdit() { if (!editing) return; editing = false; $('entry').hidden = true; $('hostbox').hidden = false; render(); }
  $('hostbox').onmousedown = function (e) { e.preventDefault(); beginEdit(); };
  $('entry').onblur = endEdit;
  $('entry').onkeydown = function (e) {
    if (e.key === 'Enter') { var v = $('entry').value; endEdit(); if (v.trim()) send('go', v); }
    else if (e.key === 'Escape') { endEdit(); send('focusPage'); e.stopPropagation(); }
  };

  $('b-rel').onclick = function () { send('reload'); };
  $('b-back').onclick = function () { send('back'); };
  $('b-fwd').onclick = function () { send('fwd'); };
  $('b-share').onclick = function () { send('share'); };
  $('b-bm').onclick = function () { send('list', 'bm'); };
  $('b-shield').onclick = function () { send('adblock'); };
  $('b-tabs').onclick = function () { if (st) showTabs(); };
  $('b-menu').onclick = function () { showMenu(); };

  function render() {
    if (!st) return;
    if (!editing) {
      var h = $('host');
      if (st.host) { h.textContent = st.host; h.classList.remove('placeholder'); }
      else { h.textContent = st.priv ? 'Private browsing' : 'Search or enter website'; h.classList.add('placeholder'); }
    }
    $('rel-svg').innerHTML = st.loading ? STOP : RELOAD;
    $('b-rel').title = st.loading ? 'Stop (Esc)' : 'Reload (F5)';
    $('b-back').classList.toggle('dis', !st.canBack);
    $('b-fwd').classList.toggle('dis', !st.canFwd);
    var n = st.tabs.length, tn = $('tabs-n');
    tn.textContent = n < 100 ? String(n) : '99+'; tn.setAttribute('class', 'tn' + (tn.textContent.length > 1 ? ' two' : ''));
    $('b-shield').classList.toggle('off', !st.adblock);
    $('shield-ck').setAttribute('visibility', st.adblock ? 'visible' : 'hidden');
  }

  window.sg.onState(function (s) { st = s; render(); });
  window.sg.onList(showList);
  window.sg.onCmd(function (c) { if (c === 'focusAddr') beginEdit(); else if (c === 'tabs' && st) showTabs(); });
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') { if (popOpen || dlgOpen) closeAll(); else if (editing) { endEdit(); send('focusPage'); } }
  });
  send('ready');
})();
